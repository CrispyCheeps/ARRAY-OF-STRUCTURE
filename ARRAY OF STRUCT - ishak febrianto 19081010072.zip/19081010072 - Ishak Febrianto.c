#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>

typedef char string[250];

struct mahasiswa{
	string nama;
	char gender[10];
	int npm;
	string universitas;
	char fakultas [15];
	char jurusan [15];
	string email;
	
};struct mahasiswa mhs[4];

int i,n,hitung=0,delay,jml=1;

void input_data(){
	
	int pil,pil2;
	puts("\t\t\t\tInput Data Mahasiswa");
    puts("\t\t\t=================================");
	printf("Masukkan jumlah data mahasiswa yang ingin dimasukkan : ");
    scanf("%d",&n);
    input :
    if(n>5){
    printf("\n\nData penuh!!\n\n");
    
    goto end;
    }
    for(i=0;i<n;i++)
    {
    printf("\n\nNama mahasiswa ke-%d\t: ",i+1);fflush(stdin);scanf("%s",&mhs[i].nama);
    printf("JENIS KELAMIN\t: ");fflush(stdin);gets(mhs[i].gender);
    printf("NPM\t\t: ");fflush(stdin);scanf("%d",&mhs[i].npm);
    printf("UNIVERSITAS\t: ");fflush(stdin);scanf("%s",&mhs[i].universitas);
    printf("FAKULTAS\t\t: ");fflush(stdin);scanf("%s",&mhs[i].fakultas);
    printf("JURUSAN\t\t: ");fflush(stdin);scanf("%s",&mhs[i].jurusan);
    printf("eMail\t\t: ");fflush(stdin);scanf("%s",&mhs[i].email);
    printf("---------------------------------------------\n");
    printf("Data mahasiswa ke-%d\n",i+1);
    printf("Nama Mahasiswa\t: %s\n",mhs[i].nama);
    printf("JENIS KELAMIN\t: %s\n",mhs[i].gender);
    printf("NPM : %d\n",mhs[i].npm);
    printf("UNIVERSITAS\t: %s\n",mhs[i].universitas);
    printf("FAKULTAS\t\t: %s\n",mhs[i].fakultas);
    printf("JURUSAN\t\t: %s\n",mhs[i].jurusan);
    printf("eMail\t\t: %s", mhs[i].email);
    printf("---------------------------------------------\n\n");
    }
    if(i>5)
    {
    printf("Data penuh!!\n");
    sleep(1);
    printf("Mengakhiri program\n");
    goto end;
    }
    printf("\nInput lagi : \n");
    puts("1. Ya");
    puts("2. Tidak");
    printf("Pilihan anda : ");
    scanf("%d",&pil);
    if(pil==1)
    {
    	goto input;
	}
    if(pil==2)
	{
		        printf("\nProses penginputan sudah selesai, dan sesuai dengan jumlah yang telah diinput.\n");
    }
    else
    {
    	printf("Data invalid!");
	}
	end :
		printf("Terimakasih telah menggunakan program kami\n\n");
		for(delay=3;delay>hitung;delay--)
		{
		printf("Kembali ke main menu dalam : %d\n",delay);
		sleep(1);
	    }
		system("cls");
		main();
}

void displayData()
{
	int back;
	puts("\t\t\t------======DISPLAY DATA MAHASISWA======------\n");
	if(n==0)
	{
		printf("\nData Masih kosong!\n\n");
		goto end;
	}
	for(i=0;i<n;i++){
    printf("Data ke-%d\n",i+1);
    printf("NAMA     : %s\n",mhs[i].nama);
    printf("JENIS KELAMIN       : %s\n",mhs[i].gender);
    printf("NPM : %d\n",mhs[i].npm);
    printf("UNIVERSTIAS    : %s\n",mhs[i].universitas);
    printf("FAKULTAS    : %s\n",mhs[i].fakultas);
    printf("JURUSAN      : %s\n",mhs[i].jurusan);
    printf("eMail : %s", mhs[i].email);
    printf("---------------------------------------------\n");
    }
    puts("1. Kembali ke menu");
    puts("2. Keluar");
    printf("Pilihan : ");
    scanf("%d",&back);
    if(back==1)
	{
    end :
    	for(delay=3;delay>hitung;delay--)
		{
		printf("Kembali ke main menu dalam : %d\n",delay);
		sleep(1);
	    }
	    system("cls");
    main();
    }
    if(back==2)
	{
		for(delay=3;delay>hitung;delay--)
		{
		printf("Anda akan keluar dalam : %d\n",delay);
		sleep(1);
	    }
	   exit(0);	
	}
}

void delete_data(){
	int b;
	char yesorno;
	if(n==0)
	{
		printf("\nData Masih kosong!\n\n");
		goto end;
	}
	for(i=0;i<n;i++){
		puts("Apakah anda ingin menghapus data mahasiswa yang telah anda input?");
		printf("Y/N :   "); scanf("%s",&yesorno);
		
		if(yesorno=='Y'||yesorno=='y'){
			for(i=0;i<n;i++){
    		printf("Data ke-%d\n",i+1);
    		printf("NAMA     : %s\n",mhs[i].nama);
    		printf("JENIS KELAMIN       : %s\n",mhs[i].gender);
    		printf("NPM : %d\n",mhs[i].npm);
    		printf("UNIVERSTIAS    : %s\n",mhs[i].universitas);
    		printf("FAKULTAS    : %s\n",mhs[i].fakultas);
    		printf("JURUSAN      : %s\n",mhs[i].jurusan);
    		printf("eMail : %s", mhs[i].email);
    		printf("---------------------------------------------\n");
    		}
    		printf("Enter data mahasiswa ke berapa yang ingin anda delete:  ");
			scanf("%d",&b);
			for(i=b-1;i<n;i++){
				mhs[i]=mhs[b];
			}
			n=n-1;
		
		}else if(yesorno=='N'||yesorno=='n'){
			displayData();
		}
    	end :
    	for(delay=3;delay>hitung;delay--)
		{
		printf("Kembali ke main menu dalam : %d\n",delay);
		sleep(1);
	    }
	    system("cls");
    	main();
	}
	}


void revisi_data(){
	char yesorno;
	int a;
	if(n==0)
	{
		printf("\nData Masih kosong!\n\n");
		goto end;
	}
	int jml=1;
	for(i=0;i<n;i++){
		puts("Apakah anda ingin merevisi data mahasiswa yang telah anda input?");
		printf("Y/N :   "); scanf("%s",&yesorno);
		
		if(yesorno=='Y'||yesorno=='y'){
			for(i=0;i<n;i++){
    		printf("Data ke-%d\n",i+1);
    		printf("NAMA     : %s\n",mhs[i].nama);
    		printf("JENIS KELAMIN       : %s\n",mhs[i].gender);
    		printf("NPM : %d\n",mhs[i].npm);
    		printf("UNIVERSTIAS    : %s\n",mhs[i].universitas);
    		printf("FAKULTAS    : %s\n",mhs[i].fakultas);
    		printf("JURUSAN      : %s\n",mhs[i].jurusan);
    		printf("eMail : %s", mhs[i].email);
    		printf("---------------------------------------------\n");
    		}
			printf("Enter data mahasiswa ke berapa yang ingin anda update:  ");
			scanf("%d", &a);
			printf("Enter the new value to be updated ");
		    printf("\n\nNama mahasiswa ke-%d\t: ",a);fflush(stdin);scanf("%s",&mhs[a-1].nama);
		    printf("JENIS KELAMIN\t: ");fflush(stdin);gets(mhs[a-1].gender);
		    printf("NPM\t\t: ");fflush(stdin);scanf("%d",&mhs[a-1].npm);
		    printf("UNIVERSITAS\t: ");fflush(stdin);scanf("%s",&mhs[a-1].universitas);
		    printf("FAKULTAS\t\t: ");fflush(stdin);scanf("%s",&mhs[a-1].fakultas);
		    printf("JURUSAN\t\t: ");fflush(stdin);scanf("%s",&mhs[a-1].jurusan);
		    printf("eMail\t\t: ");fflush(stdin);scanf("%s",&mhs[a-1].email);
		    printf("---------------------------------------------\n");
		    printf("data mahasiswa ke-%d\n",a);
		    printf("Nama Mahasiswa\t: %s\n",mhs[a-1].nama);
		    printf("JENIS KELAMIN\t: %s\n",mhs[a-1].gender);
		    printf("NPM : %d\n",mhs[a-1].npm);
		    printf("UNIVERSITAS\t: %s\n",mhs[a-1].universitas);
		    printf("FAKULTAS\t\t: %s\n",mhs[a-1].fakultas);
		    printf("JURUSAN\t\t: %s\n",mhs[a-1].jurusan);
		    printf("eMail\t\t: %s", mhs[a-1].email);
		    printf("---------------------------------------------\n\n");
					
		}else if(yesorno=='N'||yesorno=='n'){
			displayData();
		}
	}
	end :
    	for(delay=3;delay>hitung;delay--)
		{
		printf("Kembali ke main menu dalam : %d\n",delay);
		sleep(1);
	    }
	    system("cls");
    main();
	
}

int main()
{
	int menu;
	printf("\t\t\t=======================================================\n");
	printf("\t\t\t=================== ISHAK FEBRIANTO ===================\n");
	printf("\t\t\t===================   19081010072   ===================\n");
	printf("\t\t\t=================== PEMLAN KELAS C  ===================\n");
	printf("\t\t\t=======================================================\n");
	printf("\n\n\n");
	printf("-----------------\n");
	puts("MENU PROGRAM");
	puts("1. Input data mahasiswa");
	puts("2. Display data mahasiswa");
	puts("3. Revisi data");
	puts("4. Delete data");
	puts("5. Exit");
	printf("-----------------\n");
	printf("Pilihan anda :  ");
	scanf("%d",&menu);
	if(menu==1)
	{
		if(jml==5){
			goto end;
		}
		system("cls");
		input_data();
	}
	else if(menu==2)
	{
		system("cls");
		displayData();
	}
	else if(menu==3){
		system("cls");
		revisi_data();
	}
	else if(menu==4){
		system("cls");
		delete_data();
	}
	else if(menu==5)
	{
		exit(0);
	}
	else
	{
		printf("Data yang anda masukkan invalid!");
	}
	end :
	return 0;
}



